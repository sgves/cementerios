import json
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen


class SupabaseError(Exception):
    pass


class SupabaseClient:
    def __init__(self, project_url: str, anon_key: str):
        self.project_url = project_url.rstrip("/")
        self.anon_key = anon_key
        self.access_token = None
        self.codigo_cementerio = None

    def login(self, email: str, password: str, codigo_cementerio: str):
        query = urlencode({"grant_type": "password"})
        url = f"{self.project_url}/auth/v1/token?{query}"
        payload = json.dumps({"email": email, "password": password}).encode("utf-8")
        req = Request(
            url,
            data=payload,
            method="POST",
            headers={
                "apikey": self.anon_key,
                "Content-Type": "application/json",
            },
        )
        data = self._open_json(req)
        token = data.get("access_token")
        if not token:
            raise SupabaseError("No se recibio access_token en el login.")
        self.access_token = token
        self.codigo_cementerio = codigo_cementerio
        return data

    def verify_cemetery_admin(self):
        """
        Verifica que el usuario autenticado sea superadmin o tenga
        permiso cementerio.admin en el cementerio configurado.
        """
        self._ensure_login()
        self._ensure_cementerio()

        # Primero verificar si es superadmin
        params = urlencode({"select": "es_superadmin", "limit": "1"})
        users = self._rest("GET", f"/rest/v1/usuarios?{params}")
        if isinstance(users, list) and users and users[0].get("es_superadmin"):
            return True

        # Si no, verificar permiso cementerio.admin en el cementerio
        params = urlencode({
            "select": "id_permiso,permisos(codigo)",
            "id_usuario": f"eq.{self._get_user_id()}",
            "codigo_cementerio": f"eq.{self.codigo_cementerio}",
        })
        perms = self._rest("GET", f"/rest/v1/usuario_permiso?{params}")
        if not isinstance(perms, list):
            return False
        for row in perms:
            perm = row.get("permisos")
            if isinstance(perm, dict) and perm.get("codigo") == "cementerio.admin":
                return True
        return False

    def verify_cemetery_exists(self):
        """Verifica que el cementerio exista en la BD."""
        self._ensure_login()
        self._ensure_cementerio()
        params = urlencode({
            "select": "codigo,nombre",
            "codigo": f"eq.{self.codigo_cementerio}",
            "limit": "1",
        })
        data = self._rest("GET", f"/rest/v1/cementerios?{params}")
        if isinstance(data, list) and data:
            return data[0]
        return None

    def fetch_zonas(self):
        self._ensure_cementerio()
        try:
            return self._fetch_table("zonas", "id,codigo,nombre,activo",
                                     filters={"codigo_cementerio": f"eq.{self.codigo_cementerio}"})
        except SupabaseError:
            return self._fetch_table("zonas", "id,codigo,nombre",
                                     filters={"codigo_cementerio": f"eq.{self.codigo_cementerio}"})

    def fetch_tipos_titularidad(self):
        self._ensure_cementerio()
        try:
            return self._fetch_table("tipos_titularidad", "id,codigo,nombre,activo",
                                     filters={"codigo_cementerio": f"eq.{self.codigo_cementerio}"})
        except SupabaseError:
            return self._fetch_table("tipos_titularidad", "id,codigo,nombre",
                                     filters={"codigo_cementerio": f"eq.{self.codigo_cementerio}"})

    def fetch_tipos_unidad(self):
        self._ensure_cementerio()
        try:
            return self._fetch_table("tipos_unidad", "id,codigo,nombre,es_fisica,activo",
                                     filters={"codigo_cementerio": f"eq.{self.codigo_cementerio}"})
        except SupabaseError:
            return self._fetch_table("tipos_unidad", "id,codigo,nombre,es_fisica",
                                     filters={"codigo_cementerio": f"eq.{self.codigo_cementerio}"})

    def fetch_unidades_mapa(self, page_size=1000):
        """
        Descarga unidades para visualizacion en QGIS via RPC dedicada.
        Usa fn_qgis_unidades_mapa (SECURITY DEFINER) en lugar de vw_unidades_mapa
        para evitar el statement_timeout que producen las vistas de estado/concesion.
        """
        self._ensure_login()
        self._ensure_cementerio()
        offset = 0
        out = []
        while True:
            data = self._rest(
                "POST",
                "/rest/v1/rpc/fn_qgis_unidades_mapa",
                payload={
                    "p_codigo_cementerio": self.codigo_cementerio,
                    "p_offset": int(offset),
                    "p_limit": int(page_size),
                },
            )
            if not isinstance(data, list):
                raise SupabaseError("Respuesta inesperada en fn_qgis_unidades_mapa.")
            if not data:
                break
            out.extend(data)
            if len(data) < page_size:
                break
            offset += page_size
        return out

    def delete_unidades_by_ids(self, ids, chunk_size=100):
        """
        Borra unidades por id (uuid) en lotes, filtradas por cementerio.
        """
        self._ensure_login()
        self._ensure_cementerio()
        clean_ids = [str(x).strip() for x in ids if str(x).strip()]
        if not clean_ids:
            return 0
        total = 0
        for i in range(0, len(clean_ids), chunk_size):
            chunk = clean_ids[i : i + chunk_size]
            in_expr = f"in.({','.join(chunk)})"
            cem_filter = f"eq.{self.codigo_cementerio}"
            path = (
                f"/rest/v1/unidades"
                f"?id={quote(in_expr, safe='().,')}"
                f"&codigo_cementerio={quote(cem_filter)}"
            )
            self._rest("DELETE", path, extra_headers={"Prefer": "return=minimal"})
            total += len(chunk)
        return total

    def upsert_unidad_by_location(self, payload):
        """
        Upsert logico por (id_zona, numero, altura) dentro del cementerio.
        """
        existing_id = self._find_unidad_id(payload["id_zona"], payload["numero"], payload["altura"])
        if existing_id:
            self._update_unidad(existing_id, payload)
            return {"action": "update", "id": existing_id}
        payload["codigo_cementerio"] = self.codigo_cementerio
        new_id = self._insert_unidad(payload)
        return {"action": "insert", "id": new_id}

    def upsert_unidades_geocodificacion_rpc(self, rows):
        self._ensure_cementerio()
        data = self._rest(
            "POST",
            "/rest/v1/rpc/fn_unidades_upsert_geocodificacion",
            payload={
                "p_codigo_cementerio": self.codigo_cementerio,
                "p_items": rows,
            },
        )
        if not isinstance(data, dict):
            raise SupabaseError("Respuesta inesperada al ejecutar RPC de geocodificacion.")
        return data

    def _fetch_table(self, table: str, select_fields: str, filters: dict | None = None):
        self._ensure_login()
        query_params = {"select": select_fields, "order": "id.asc"}
        if filters:
            query_params.update(filters)
        params = urlencode(query_params)
        url = f"{self.project_url}/rest/v1/{table}?{params}"
        req = Request(
            url,
            method="GET",
            headers={
                "apikey": self.anon_key,
                "Authorization": f"Bearer {self.access_token}",
                "Accept": "application/json",
            },
        )
        data = self._open_json(req)
        if not isinstance(data, list):
            raise SupabaseError(f"Respuesta inesperada en {table}.")
        return data

    def _find_unidad_id(self, id_zona: str, numero: str, altura: int):
        self._ensure_cementerio()
        params = urlencode(
            {
                "select": "id",
                "id_zona": f"eq.{id_zona}",
                "numero": f"eq.{numero}",
                "altura": f"eq.{altura}",
                "codigo_cementerio": f"eq.{self.codigo_cementerio}",
                "limit": 1,
            }
        )
        data = self._rest("GET", f"/rest/v1/unidades?{params}")
        if isinstance(data, list) and len(data) > 0:
            return str(data[0].get("id"))
        return None

    def _update_unidad(self, unidad_id: str, payload: dict):
        params = urlencode({"id": f"eq.{unidad_id}"})
        self._rest(
            "PATCH",
            f"/rest/v1/unidades?{params}",
            payload=payload,
            extra_headers={"Prefer": "return=representation"},
        )

    def _insert_unidad(self, payload: dict):
        if "codigo_cementerio" not in payload:
            payload["codigo_cementerio"] = self.codigo_cementerio
        data = self._rest(
            "POST",
            "/rest/v1/unidades",
            payload=payload,
            extra_headers={"Prefer": "return=representation"},
        )
        if isinstance(data, list) and len(data) > 0 and data[0].get("id"):
            return str(data[0]["id"])
        return None

    def _rest(self, method: str, path: str, payload=None, extra_headers=None):
        self._ensure_login()
        url = f"{self.project_url}{path}"
        headers = {
            "apikey": self.anon_key,
            "Authorization": f"Bearer {self.access_token}",
            "Accept": "application/json",
        }
        if payload is not None:
            headers["Content-Type"] = "application/json"
        if extra_headers:
            headers.update(extra_headers)
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = Request(url, data=data, method=method, headers=headers)
        return self._open_json(req)

    def _ensure_login(self):
        if not self.access_token:
            raise SupabaseError("No hay sesion activa.")

    def _ensure_cementerio(self):
        if not self.codigo_cementerio:
            raise SupabaseError("No se ha configurado un codigo de cementerio.")

    def _get_user_id(self):
        """Extrae el user_id del JWT (campo sub del payload)."""
        if not self.access_token:
            return None
        import base64
        parts = self.access_token.split(".")
        if len(parts) < 2:
            return None
        padded = parts[1] + "=" * (4 - len(parts[1]) % 4)
        try:
            payload = json.loads(base64.urlsafe_b64decode(padded))
            return payload.get("sub")
        except Exception:
            return None

    def _open_json(self, req: Request):
        try:
            with urlopen(req, timeout=25) as res:
                raw = res.read().decode("utf-8")
                return json.loads(raw) if raw else {}
        except HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")
            raise SupabaseError(f"HTTP {e.code}: {detail}") from e
        except URLError as e:
            raise SupabaseError(f"Error de conexion: {e.reason}") from e
        except json.JSONDecodeError as e:
            raise SupabaseError(f"Respuesta JSON invalida: {e}") from e
