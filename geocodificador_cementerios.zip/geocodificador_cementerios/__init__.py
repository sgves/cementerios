def classFactory(iface):
    from .plugin import GeocodificadorCementeriosPlugin

    return GeocodificadorCementeriosPlugin(iface)

