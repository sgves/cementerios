from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)


class PluginSettingsDialog(QDialog):
    def __init__(self, parent=None, defaults=None):
        super().__init__(parent)
        self.setWindowTitle("Configuracion - Geocodificador de cementerios")
        self.setModal(True)
        self.resize(620, 240)

        defaults = defaults or {}

        self.layer_name_edit = QLineEdit(defaults.get("line_layer_name", "lineas_geocodificacion"))
        self.url_edit = QLineEdit(defaults.get("supabase_url", ""))
        self.url_edit.setPlaceholderText("https://xxxx.supabase.co")
        self.anon_key_edit = QLineEdit(defaults.get("supabase_anon_key", ""))
        self.anon_key_edit.setPlaceholderText("Anon key")
        self.remember_email_check = QCheckBox("Recordar email de ultimo login")
        self.remember_email_check.setChecked(bool(defaults.get("remember_email", True)))

        form = QFormLayout()
        form.addRow("Capa lineas referencia", self.layer_name_edit)
        form.addRow("Supabase URL", self.url_edit)
        form.addRow("Supabase anon key", self.anon_key_edit)
        form.addRow("", self.remember_email_check)

        btn_cancel = QPushButton("Cancelar")
        btn_accept = QPushButton("Guardar")
        btn_accept.setDefault(True)
        btn_cancel.clicked.connect(self.reject)
        btn_accept.clicked.connect(self.accept)

        footer = QHBoxLayout()
        footer.addStretch(1)
        footer.addWidget(btn_cancel)
        footer.addWidget(btn_accept)

        root = QVBoxLayout()
        root.addLayout(form)
        root.addLayout(footer)
        self.setLayout(root)

    def values(self):
        return {
            "line_layer_name": self.layer_name_edit.text().strip() or "lineas_geocodificacion",
            "supabase_url": self.url_edit.text().strip(),
            "supabase_anon_key": self.anon_key_edit.text().strip(),
            "remember_email": self.remember_email_check.isChecked(),
        }

