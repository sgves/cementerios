# Submodulo de interfaces Qt del plugin.

