from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)


class SupabaseLoginDialog(QDialog):
    def __init__(self, parent=None, defaults=None):
        super().__init__(parent)
        self.setWindowTitle("Geocodificador de cementerios - Login Supabase")
        self.setModal(True)
        self.resize(560, 260)

        defaults = defaults or {}

        self.url_edit = QLineEdit(defaults.get("url", ""))
        self.url_edit.setPlaceholderText("https://xxxx.supabase.co")

        self.key_edit = QLineEdit(defaults.get("anon_key", ""))
        self.key_edit.setPlaceholderText("Anon key")

        self.email_edit = QLineEdit(defaults.get("email", ""))
        self.email_edit.setPlaceholderText("usuario@dominio.com")

        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setPlaceholderText("Contrasena")

        self.cementerio_edit = QLineEdit(defaults.get("codigo_cementerio", ""))
        self.cementerio_edit.setPlaceholderText("cementeriodezaragoza")

        self.remember_check = QCheckBox("Recordar URL, anon key, email y cementerio")
        self.remember_check.setChecked(True)

        form = QFormLayout()
        form.addRow("URL proyecto", self.url_edit)
        form.addRow("Anon key", self.key_edit)
        form.addRow("Email", self.email_edit)
        form.addRow("Contrasena", self.password_edit)
        form.addRow("Codigo cementerio", self.cementerio_edit)

        btn_cancel = QPushButton("Cancelar")
        btn_accept = QPushButton("Conectar")
        btn_accept.setDefault(True)
        btn_cancel.clicked.connect(self.reject)
        btn_accept.clicked.connect(self.accept)

        footer = QHBoxLayout()
        footer.addWidget(self.remember_check)
        footer.addStretch(1)
        footer.addWidget(btn_cancel)
        footer.addWidget(btn_accept)

        root = QVBoxLayout()
        root.addLayout(form)
        root.addLayout(footer)
        self.setLayout(root)

        self.url_edit.setFocus(Qt.OtherFocusReason)

    def values(self):
        return {
            "url": self.url_edit.text().strip(),
            "anon_key": self.key_edit.text().strip(),
            "email": self.email_edit.text().strip(),
            "password": self.password_edit.text(),
            "codigo_cementerio": self.cementerio_edit.text().strip().lower(),
            "remember": self.remember_check.isChecked(),
        }

