from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QComboBox,
)


class GeocodingMetadataDialog(QDialog):
    def __init__(self, parent=None, tipos_titularidad=None):
        super().__init__(parent)
        self.setWindowTitle("Metadatos de unidades a generar")
        self.setModal(True)
        self.resize(560, 320)

        tipos_titularidad = tipos_titularidad or []

        self.reservada_check = QCheckBox("Reservada")
        self.tipo_tit_combo = QComboBox()
        self.tipo_tit_combo.addItem("(Sin tipo de titularidad)", None)
        for row in tipos_titularidad:
            label = " - ".join(
                [p for p in [str(row.get("codigo") or "").strip(), str(row.get("nombre") or "").strip()] if p]
            ) or str(row.get("id"))
            self.tipo_tit_combo.addItem(label, int(row.get("id")))

        self.obs_edit = QTextEdit()
        self.obs_edit.setPlaceholderText("Observaciones opcionales...")
        self.obs_edit.setMinimumHeight(110)

        help_lbl = QLabel(
            "Estos metadatos se aplican a todas las unidades del lote generado en esta ejecucion."
        )
        help_lbl.setWordWrap(True)

        form = QFormLayout()
        form.addRow("Reservada", self.reservada_check)
        form.addRow("Tipo titularidad (opcional)", self.tipo_tit_combo)
        form.addRow("Observaciones (opcional)", self.obs_edit)

        btn_cancel = QPushButton("Cancelar")
        btn_accept = QPushButton("Generar preview")
        btn_accept.setDefault(True)
        btn_cancel.clicked.connect(self.reject)
        btn_accept.clicked.connect(self.accept)

        footer = QHBoxLayout()
        footer.addStretch(1)
        footer.addWidget(btn_cancel)
        footer.addWidget(btn_accept)

        root = QVBoxLayout()
        root.addWidget(help_lbl)
        root.addLayout(form)
        root.addLayout(footer)
        self.setLayout(root)

    def values(self):
        obs = self.obs_edit.toPlainText().strip()
        return {
            "reservada": self.reservada_check.isChecked(),
            "id_tipo_titularidad": self.tipo_tit_combo.currentData(),
            "observaciones": obs if obs else None,
        }

