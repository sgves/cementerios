import csv
import os
from datetime import datetime, timezone


class LocalMasterStore:
    def __init__(self, datos_dir: str):
        self.datos_dir = datos_dir
        self.zonas_csv = os.path.join(datos_dir, "maestra_zonas_local.csv")
        self.titularidades_csv = os.path.join(datos_dir, "maestra_tipos_titularidad_local.csv")
        self.tipos_unidad_csv = os.path.join(datos_dir, "maestra_tipos_unidad_local.csv")
        self.tipos_geocod_csv = os.path.join(datos_dir, "maestra_tipos_geocodificacion_local.csv")

    def ensure_schema(self):
        self._ensure_parent_dir()
        self._ensure_csv_header(
            self.zonas_csv,
            ["id_zona", "codigo", "nombre", "etiqueta", "activo", "updated_at_sync"],
        )
        self._ensure_csv_header(
            self.titularidades_csv,
            [
                "id_tipo_titularidad",
                "codigo",
                "nombre",
                "etiqueta",
                "activo",
                "updated_at_sync",
            ],
        )
        self._ensure_csv_header(
            self.tipos_unidad_csv,
            [
                "id_tipo_unidad",
                "codigo",
                "nombre",
                "etiqueta",
                "es_fisica",
                "activo",
                "updated_at_sync",
            ],
        )
        self._ensure_csv_header(
            self.tipos_geocod_csv,
            ["codigo", "nombre", "activo", "updated_at_sync"],
        )

    def sync_zonas(self, rows):
        now_iso = datetime.now(timezone.utc).isoformat()
        payload = []
        for r in rows:
            codigo = (r.get("codigo") or "").strip()
            nombre = (r.get("nombre") or "").strip()
            etiqueta = " - ".join([p for p in [codigo, nombre] if p]) or r.get("id", "")
            activo = 1 if bool(r.get("activo", True)) else 0
            payload.append(
                {
                    "id_zona": str(r.get("id")),
                    "codigo": codigo,
                    "nombre": nombre,
                    "etiqueta": etiqueta,
                    "activo": str(activo),
                    "updated_at_sync": now_iso,
                }
            )
        self._write_csv(
            self.zonas_csv,
            ["id_zona", "codigo", "nombre", "etiqueta", "activo", "updated_at_sync"],
            payload,
        )
        return len(payload)

    def sync_tipos_titularidad(self, rows):
        now_iso = datetime.now(timezone.utc).isoformat()
        payload = []
        for r in rows:
            codigo = (r.get("codigo") or "").strip()
            nombre = (r.get("nombre") or "").strip()
            etiqueta = " - ".join([p for p in [codigo, nombre] if p]) or str(r.get("id"))
            activo = 1 if bool(r.get("activo", True)) else 0
            payload.append(
                {
                    "id_tipo_titularidad": str(int(r.get("id"))),
                    "codigo": codigo,
                    "nombre": nombre,
                    "etiqueta": etiqueta,
                    "activo": str(activo),
                    "updated_at_sync": now_iso,
                }
            )
        self._write_csv(
            self.titularidades_csv,
            [
                "id_tipo_titularidad",
                "codigo",
                "nombre",
                "etiqueta",
                "activo",
                "updated_at_sync",
            ],
            payload,
        )
        return len(payload)

    def sync_tipos_unidad(self, rows):
        now_iso = datetime.now(timezone.utc).isoformat()
        payload = []
        for r in rows:
            codigo = (r.get("codigo") or "").strip()
            nombre = (r.get("nombre") or "").strip()
            etiqueta = " - ".join([p for p in [codigo, nombre] if p]) or str(r.get("id"))
            activo = 1 if bool(r.get("activo", True)) else 0
            es_fisica = 1 if bool(r.get("es_fisica", True)) else 0
            payload.append(
                {
                    "id_tipo_unidad": str(int(r.get("id"))),
                    "codigo": codigo,
                    "nombre": nombre,
                    "etiqueta": etiqueta,
                    "es_fisica": str(es_fisica),
                    "activo": str(activo),
                    "updated_at_sync": now_iso,
                }
            )
        self._write_csv(
            self.tipos_unidad_csv,
            [
                "id_tipo_unidad",
                "codigo",
                "nombre",
                "etiqueta",
                "es_fisica",
                "activo",
                "updated_at_sync",
            ],
            payload,
        )
        return len(payload)

    def sync_tipos_geocodificacion_requeridos(self):
        now_iso = datetime.now(timezone.utc).isoformat()
        rows = [
            {"codigo": "XY", "nombre": "Por X e Y", "activo": "1", "updated_at_sync": now_iso},
            {"codigo": "X_UNI", "nombre": "Por X unidireccional", "activo": "1", "updated_at_sync": now_iso},
            {"codigo": "X_BID", "nombre": "Por X bidireccional", "activo": "1", "updated_at_sync": now_iso},
            {"codigo": "Y_UNI", "nombre": "Por Y unidireccional", "activo": "1", "updated_at_sync": now_iso},
            {"codigo": "Y_BID", "nombre": "Por Y bidireccional", "activo": "1", "updated_at_sync": now_iso},
        ]
        self._write_csv(
            self.tipos_geocod_csv,
            ["codigo", "nombre", "activo", "updated_at_sync"],
            rows,
        )
        return len(rows)

    def _ensure_parent_dir(self):
        if self.datos_dir and not os.path.exists(self.datos_dir):
            os.makedirs(self.datos_dir, exist_ok=True)

    def _ensure_csv_header(self, path, headers):
        if os.path.exists(path):
            return
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()

    def _write_csv(self, path, headers, rows):
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(rows)

