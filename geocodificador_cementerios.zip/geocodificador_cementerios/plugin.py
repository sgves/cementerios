from pathlib import Path

from qgis.PyQt.QtCore import QCoreApplication, QSettings
from qgis.PyQt.QtGui import QAction, QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import (
    Qgis,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsMessageLog,
    QgsPointXY,
    QgsProject,
    QgsVectorLayer,
)
from qgis.PyQt.QtCore import QVariant

from .geocoding_engine import generate_points_for_feature
from .local_master_store import LocalMasterStore
from .supabase_client import SupabaseClient, SupabaseError
from .ui.metadata_dialog import GeocodingMetadataDialog
from .ui.login_dialog import SupabaseLoginDialog
from .ui.settings_dialog import PluginSettingsDialog


class GeocodificadorCementeriosPlugin:
    REQUIRED_LINE_FIELDS = [
        "ZONE",
        "X_FROM",
        "X_TO",
        "Y_FROM",
        "Y_TO",
        "TIPO_GEOCO",
        "UNIT_TYPE",
    ]

    def __init__(self, iface):
        self.iface = iface
        self.toolbar = None
        self.action = None
        self.action_settings = None
        self.action_run_geocoding = None
        self.action_sync_preview = None
        self.action_sync_unidades_ro = None
        self.action_delete_selected_units = None
        self.menu_name = self.tr("Geocodificador de cementerios")
        self.client = None
        self.master_data = {
            "zonas": [],
            "tipos_titularidad": [],
            "tipos_unidad": [],
        }

    def tr(self, text):
        return QCoreApplication.translate("GeocodificadorCementerios", text)

    def _icon(self, filename):
        return QIcon(str(Path(__file__).resolve().parent / "icons" / filename))

    def initGui(self):
        self.toolbar = self.iface.addToolBar(self.menu_name)
        self.toolbar.setObjectName("GeocodificadorCementeriosToolbar")

        self.action = QAction(
            self._icon("connect_Supab.png"),
            self.tr("Conectar y cargar maestras"),
            self.iface.mainWindow(),
        )
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu(self.menu_name, self.action)
        self.toolbar.addAction(self.action)

        self.action_run_geocoding = QAction(
            self._icon("geocode_preview.png"),
            self.tr("Ejecutar geocodificacion (preview)"),
            self.iface.mainWindow(),
        )
        self.action_run_geocoding.triggered.connect(self.run_geocoding_preview)
        self.iface.addPluginToMenu(self.menu_name, self.action_run_geocoding)
        self.toolbar.addAction(self.action_run_geocoding)

        self.action_sync_preview = QAction(
            self._icon("geocode_upload_Supab.png"),
            self.tr("Sincronizar preview a Supabase"),
            self.iface.mainWindow(),
        )
        self.action_sync_preview.triggered.connect(self.sync_preview_to_supabase)
        self.iface.addPluginToMenu(self.menu_name, self.action_sync_preview)
        self.toolbar.addAction(self.action_sync_preview)

        self.action_sync_unidades_ro = QAction(
            self._icon("download_units_Supab.png"),
            self.tr("Sincronizar unidades desde Supabase (solo lectura)"),
            self.iface.mainWindow(),
        )
        self.action_sync_unidades_ro.triggered.connect(self.sync_unidades_from_supabase_readonly)
        self.iface.addPluginToMenu(self.menu_name, self.action_sync_unidades_ro)
        self.toolbar.addAction(self.action_sync_unidades_ro)

        self.action_delete_selected_units = QAction(
            self._icon("delete.png"),
            self.tr("Borrar unidades seleccionadas (QGIS + Supabase)"),
            self.iface.mainWindow(),
        )
        self.action_delete_selected_units.triggered.connect(self.delete_selected_unidades)
        self.iface.addPluginToMenu(self.menu_name, self.action_delete_selected_units)
        self.toolbar.addAction(self.action_delete_selected_units)

        self.action_settings = QAction(
            self._icon("config.png"),
            self.tr("Configuracion"),
            self.iface.mainWindow(),
        )
        self.action_settings.triggered.connect(self.open_settings)
        self.iface.addPluginToMenu(self.menu_name, self.action_settings)
        self.toolbar.addAction(self.action_settings)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu(self.menu_name, self.action)
        if self.action_settings:
            self.iface.removePluginMenu(self.menu_name, self.action_settings)
        if self.action_run_geocoding:
            self.iface.removePluginMenu(self.menu_name, self.action_run_geocoding)
        if self.action_sync_preview:
            self.iface.removePluginMenu(self.menu_name, self.action_sync_preview)
        if self.action_sync_unidades_ro:
            self.iface.removePluginMenu(self.menu_name, self.action_sync_unidades_ro)
        if self.action_delete_selected_units:
            self.iface.removePluginMenu(self.menu_name, self.action_delete_selected_units)
        if self.toolbar is not None:
            self.toolbar.clear()
            del self.toolbar
            self.toolbar = None
        self.action = None
        self.action_settings = None
        self.action_run_geocoding = None
        self.action_sync_preview = None
        self.action_sync_unidades_ro = None
        self.action_delete_selected_units = None

    def run(self):
        defaults = self._load_login_defaults()
        dlg = SupabaseLoginDialog(self.iface.mainWindow(), defaults=defaults)
        if dlg.exec_() != dlg.Accepted:
            return

        values = dlg.values()
        if not values["url"] or not values["anon_key"] or not values["email"] or not values["password"]:
            self._error("Debes informar URL, anon key, email y contrasena.")
            return
        if not values["codigo_cementerio"]:
            self._error("Debes informar el codigo del cementerio.")
            return

        try:
            client = SupabaseClient(values["url"], values["anon_key"])
            client.login(values["email"], values["password"], values["codigo_cementerio"])

            cem_info = client.verify_cemetery_exists()
            if not cem_info:
                self._error(
                    f"El cementerio '{values['codigo_cementerio']}' no existe en la base de datos."
                )
                return

            is_admin = client.verify_cemetery_admin()
            if not is_admin:
                self._error(
                    f"No tienes permisos de administracion en el cementerio "
                    f"'{cem_info.get('nombre', values['codigo_cementerio'])}'.\n\n"
                    "Se requiere permiso 'cementerio.admin' o ser superadministrador."
                )
                return

            zonas = client.fetch_zonas()
            tipos_titularidad = client.fetch_tipos_titularidad()
            tipos_unidad = client.fetch_tipos_unidad()

            self.client = client
            self.master_data["zonas"] = zonas
            self.master_data["tipos_titularidad"] = tipos_titularidad
            self.master_data["tipos_unidad"] = tipos_unidad

            datos_dir = self._local_datos_dir()
            store = LocalMasterStore(datos_dir)
            store.ensure_schema()
            total_zonas = store.sync_zonas(zonas)
            total_tit = store.sync_tipos_titularidad(tipos_titularidad)
            total_tipos_uni = store.sync_tipos_unidad(tipos_unidad)
            total_tipos_geocod = store.sync_tipos_geocodificacion_requeridos()
            zonas_layer = self._ensure_local_csv_layer(
                store.zonas_csv,
                "maestra_zonas_local",
                "maestra_zonas_local",
            )
            self._ensure_local_csv_layer(
                store.titularidades_csv,
                "maestra_tipos_titularidad_local",
                "maestra_tipos_titularidad_local",
            )
            tipos_unidad_layer = self._ensure_local_csv_layer(
                store.tipos_unidad_csv,
                "maestra_tipos_unidad_local",
                "maestra_tipos_unidad_local",
            )
            tipos_geocod_layer = self._ensure_local_csv_layer(
                store.tipos_geocod_csv,
                "maestra_tipos_geocodificacion_local",
                "maestra_tipos_geocodificacion_local",
            )
            line_layer_name = self._load_plugin_settings()["line_layer_name"]

            schema_msg = self._validate_configured_line_layer(line_layer_name)

            if values["remember"]:
                self._save_login_defaults(values)

            cem_nombre = cem_info.get("nombre", values["codigo_cementerio"])
            self._info(
                (
                    f"Conexion correcta.\n"
                    f"Cementerio: {cem_nombre} ({values['codigo_cementerio']})\n\n"
                    f"- Zonas: {len(zonas)}\n"
                    f"- Tipos titularidad: {len(tipos_titularidad)}\n"
                    f"- Tipos unidad: {len(tipos_unidad)}\n\n"
                    f"Maestras locales sincronizadas en:\n{datos_dir}\n"
                    f"- maestra_zonas_local: {total_zonas}\n"
                    f"- maestra_tipos_titularidad_local: {total_tit}\n"
                    f"- maestra_tipos_unidad_local: {total_tipos_uni}\n"
                    f"- maestra_tipos_geocodificacion_local: {total_tipos_geocod}\n\n"
                    "Nota: las relaciones de campos con maestras no se aplican automaticamente.\n"
                    "Configuralas manualmente en el proyecto QGIS.\n\n"
                    f"{schema_msg}"
                )
            )
            QgsMessageLog.logMessage(
                f"Sesion Supabase iniciada para cementerio '{values['codigo_cementerio']}', "
                "maestras cargadas y cache local actualizada.",
                "GeocodificadorCementerios",
                level=Qgis.Info,
            )
        except SupabaseError as e:
            self._error(f"Error Supabase: {e}")
        except Exception as e:
            self._error(f"Error inesperado: {e}")

    def _load_login_defaults(self):
        s = QSettings()
        remember = s.value("geocodificador_cementerios/remember_email", True, bool)
        return {
            "url": s.value("geocodificador_cementerios/supabase_url", "", str),
            "anon_key": s.value("geocodificador_cementerios/supabase_anon_key", "", str),
            "email": (
                s.value("geocodificador_cementerios/supabase_email", "", str)
                if remember else ""
            ),
            "codigo_cementerio": s.value("geocodificador_cementerios/codigo_cementerio", "", str),
        }

    def _save_login_defaults(self, values):
        s = QSettings()
        s.setValue("geocodificador_cementerios/supabase_url", values["url"])
        s.setValue("geocodificador_cementerios/supabase_anon_key", values["anon_key"])
        s.setValue("geocodificador_cementerios/codigo_cementerio", values["codigo_cementerio"])
        if s.value("geocodificador_cementerios/remember_email", True, bool):
            s.setValue("geocodificador_cementerios/supabase_email", values["email"])

    def open_settings(self):
        defaults = self._load_plugin_settings()
        dlg = PluginSettingsDialog(self.iface.mainWindow(), defaults=defaults)
        if dlg.exec_() != dlg.Accepted:
            return
        values = dlg.values()
        self._save_plugin_settings(values)
        self._info("Configuracion guardada.")

    def run_geocoding_preview(self):
        settings = self._load_plugin_settings()
        line_layer_name = settings["line_layer_name"]
        layer, msg = self._get_validated_line_layer(line_layer_name)
        if not layer:
            self._error(
                "No se puede iniciar geocodificacion.\n\n"
                f"{msg}"
            )
            return

        selected = layer.selectedFeatureCount()
        if selected <= 0:
            self._error(
                f"La capa '{line_layer_name}' no tiene lineas seleccionadas.\n"
                "Selecciona al menos una linea de referencia antes de ejecutar."
            )
            return

        meta = self._ask_geocoding_metadata()
        if meta is None:
            return

        preview_layer, warnings = self._build_preview_layer(layer, meta)
        if not preview_layer:
            self._error("No se pudo generar la capa de preview de geocodificacion.")
            return

        warn_text = ""
        if warnings:
            warn_text = "\n\nAdvertencias:\n- " + "\n- ".join(warnings[:10])

        self._info(
            "Preview de geocodificacion generado.\n\n"
            f"Capa lineas: {line_layer_name}\n"
            f"Lineas seleccionadas: {selected}\n"
            f"Puntos generados: {preview_layer.featureCount()}\n\n"
            "Se ha creado/actualizado la capa temporal 'geocodificacion_preview'."
            + warn_text
        )

    def sync_preview_to_supabase(self):
        if not self.client:
            self._error("Debes iniciar sesion y cargar maestras antes de sincronizar.")
            return
        project = QgsProject.instance()
        matches = project.mapLayersByName("geocodificacion_preview")
        if not matches:
            self._error("No existe la capa 'geocodificacion_preview'. Ejecuta primero el preview.")
            return
        layer = matches[0]
        if not isinstance(layer, QgsVectorLayer):
            self._error("La capa 'geocodificacion_preview' no es vectorial.")
            return

        rows = []
        for f in layer.getFeatures():
            payload = self._payload_unidad_from_preview(f)
            if payload is None:
                continue
            rows.append(payload)

        if not rows:
            self._error("No hay filas validas en preview para sincronizar.")
            return

        try:
            result = self.client.upsert_unidades_geocodificacion_rpc(rows)
        except Exception as e:
            self._error(f"Fallo al ejecutar RPC de geocodificacion: {e}")
            return

        msg = (
            "Sincronizacion finalizada.\n\n"
            f"- Insertadas: {int(result.get('inserted', 0))}\n"
            f"- Actualizadas: {int(result.get('updated', 0))}\n"
            f"- Omitidas: {int(result.get('skipped', 0))}"
        )
        errors = result.get("errors") or []
        if isinstance(errors, list) and errors:
            to_show = [str(x.get("error", x)) if isinstance(x, dict) else str(x) for x in errors[:10]]
            msg += "\n\nErrores (primeros 10):\n- " + "\n- ".join(to_show)
        self._info(msg)

    def sync_unidades_from_supabase_readonly(self):
        if not self.client:
            self._error("Debes iniciar sesion y cargar maestras antes de sincronizar unidades.")
            return
        try:
            rows = self.client.fetch_unidades_mapa(page_size=1000)
        except Exception as e:
            self._error(f"Error descargando unidades desde Supabase: {e}")
            return

        project = QgsProject.instance()
        old = project.mapLayersByName("supabase_unidades_ro")
        for lyr in old:
            project.removeMapLayer(lyr.id())

        layer = QgsVectorLayer("Point?crs=EPSG:4326", "supabase_unidades_ro", "memory")
        if not layer.isValid():
            self._error("No se pudo crear la capa de unidades en QGIS.")
            return

        pr = layer.dataProvider()
        pr.addAttributes(
            [
                QgsField("id_unidad", QVariant.String, len=40),
                QgsField("zona_cod", QVariant.String, len=40),
                QgsField("numero", QVariant.String, len=40),
                QgsField("altura", QVariant.Int),
                QgsField("etiqueta", QVariant.String, len=255),
                QgsField("id_tipo_uni", QVariant.Int),
            ]
        )
        layer.updateFields()
        qfs = layer.fields()

        feats = []
        for r in rows:
            try:
                lat = float(r.get("lat"))
                lng = float(r.get("lng"))
            except (TypeError, ValueError):
                continue
            f = QgsFeature()
            f.setFields(qfs)
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lng, lat)))
            f["id_unidad"] = str(r.get("id_unidad") or "")
            f["zona_cod"] = str(r.get("zona_codigo") or "")
            f["numero"] = str(r.get("numero") or "")
            altura_val = r.get("altura")
            try:
                f["altura"] = int(altura_val) if altura_val is not None else None
            except (TypeError, ValueError):
                f["altura"] = None
            f["etiqueta"] = str(r.get("unidad_etiqueta") or "")
            tipo_val = r.get("id_tipo_unidad")
            try:
                f["id_tipo_uni"] = int(tipo_val) if tipo_val is not None else None
            except (TypeError, ValueError):
                f["id_tipo_uni"] = None
            feats.append(f)

        if feats:
            pr.addFeatures(feats)
            layer.updateExtents()
        layer.setReadOnly(True)
        project.addMapLayer(layer)

        self._info(
            "Sincronizacion de unidades completada.\n\n"
            f"- Registros descargados: {len(rows)}\n"
            f"- Geometrias cargadas en capa: {len(feats)}\n\n"
            "Capa creada: 'supabase_unidades_ro' (solo lectura)."
        )

    def delete_selected_unidades(self):
        if not self.client:
            self._error("Debes iniciar sesion y cargar maestras antes de borrar unidades.")
            return
        project = QgsProject.instance()
        matches = project.mapLayersByName("supabase_unidades_ro")
        if not matches:
            self._error("No existe la capa 'supabase_unidades_ro'. Sincronizala primero.")
            return
        layer = matches[0]
        if not isinstance(layer, QgsVectorLayer):
            self._error("La capa 'supabase_unidades_ro' no es vectorial.")
            return

        selected = layer.selectedFeatures()
        if not selected:
            self._error("No hay unidades seleccionadas en la capa 'supabase_unidades_ro'.")
            return

        ids = [str(f["id_unidad"] or "").strip() for f in selected if str(f["id_unidad"] or "").strip()]
        if not ids:
            self._error("No se pudieron extraer ids de unidades seleccionadas.")
            return

        answer = QMessageBox.question(
            self.iface.mainWindow(),
            self.menu_name,
            (
                "Se van a borrar unidades seleccionadas en Supabase y de la capa temporal.\n\n"
                f"Total seleccionadas: {len(ids)}\n\n"
                "Esta accion no se puede deshacer. ¿Continuar?"
            ),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        try:
            total_deleted = self.client.delete_unidades_by_ids(ids, chunk_size=100)
        except Exception as e:
            self._error(f"Error borrando en Supabase: {e}")
            return

        # Refrescar capa temporal desde fuente para evitar incompatibilidades API QGIS.
        self.sync_unidades_from_supabase_readonly()

        self._info(
            "Borrado completado.\n\n"
            f"- Unidades eliminadas en Supabase: {total_deleted}\n"
            "- Capa temporal actualizada desde Supabase."
        )

    def _load_plugin_settings(self):
        s = QSettings()
        return {
            "line_layer_name": s.value(
                "geocodificador_cementerios/line_layer_name",
                "lineas_geocodificacion",
                str,
            ),
            "supabase_url": s.value("geocodificador_cementerios/supabase_url", "", str),
            "supabase_anon_key": s.value("geocodificador_cementerios/supabase_anon_key", "", str),
            "remember_email": s.value("geocodificador_cementerios/remember_email", True, bool),
        }

    def _save_plugin_settings(self, values):
        s = QSettings()
        s.setValue("geocodificador_cementerios/line_layer_name", values["line_layer_name"])
        s.setValue("geocodificador_cementerios/supabase_url", values["supabase_url"])
        s.setValue("geocodificador_cementerios/supabase_anon_key", values["supabase_anon_key"])
        s.setValue("geocodificador_cementerios/remember_email", values["remember_email"])

    def _local_datos_dir(self):
        project = QgsProject.instance()
        project_path = project.fileName()
        if project_path:
            base_dir = Path(project_path).resolve().parent
        else:
            # Fallback si el proyecto aun no se ha guardado.
            base_dir = Path(project.homePath() or Path.home())
        datos_dir = base_dir / "datos"
        datos_dir.mkdir(parents=True, exist_ok=True)
        return str(datos_dir)

    def _ensure_local_csv_layer(self, csv_path, table_name, layer_name):
        csv_uri = Path(csv_path).resolve().as_uri()
        uri = f"{csv_uri}?type=csv&delimiter=,&detectTypes=yes&geomType=none&watchFile=no"
        project = QgsProject.instance()
        existing = project.mapLayersByName(layer_name)
        if existing:
            return existing[0]
        layer = QgsVectorLayer(uri, layer_name, "delimitedtext")
        if not layer.isValid():
            QgsMessageLog.logMessage(
                f"No se pudo cargar capa local {table_name} desde {csv_path}",
                "GeocodificadorCementerios",
                level=Qgis.Warning,
            )
            return None
        project.addMapLayer(layer)
        return layer

    def _get_validated_line_layer(self, layer_name):
        project = QgsProject.instance()
        matches = project.mapLayersByName(layer_name)
        if not matches:
            msg = (
                f"No se encontro la capa configurada '{layer_name}'. "
                "Configura el nombre correcto en Geocodificador > Configuracion."
            )
            QgsMessageLog.logMessage(msg, "GeocodificadorCementerios", level=Qgis.Warning)
            return None, msg

        layer = matches[0]
        if not isinstance(layer, QgsVectorLayer):
            msg = f"La capa '{layer_name}' existe pero no es vectorial."
            QgsMessageLog.logMessage(msg, "GeocodificadorCementerios", level=Qgis.Warning)
            return None, msg

        fields = {f.name() for f in layer.fields()}
        missing = [f for f in self.REQUIRED_LINE_FIELDS if f not in fields]
        # Compatibilidad con esquema legacy.
        if "ZONE" in missing and "ZONA" in fields:
            missing.remove("ZONE")
        if "UNIT_TYPE" in missing and "UINIT_TYPE" in fields:
            missing.remove("UNIT_TYPE")

        if missing:
            msg = (
                f"Capa '{layer_name}' localizada, pero faltan campos obligatorios: "
                + ", ".join(missing)
            )
            QgsMessageLog.logMessage(msg, "GeocodificadorCementerios", level=Qgis.Warning)
            return None, msg

        msg = f"Capa '{layer_name}' validada correctamente."
        QgsMessageLog.logMessage(msg, "GeocodificadorCementerios", level=Qgis.Info)
        return layer, msg

    def _validate_configured_line_layer(self, layer_name):
        _layer, msg = self._get_validated_line_layer(layer_name)
        return msg

    def _ask_geocoding_metadata(self):
        tipos = self._active_tipos_titularidad()
        dlg = GeocodingMetadataDialog(self.iface.mainWindow(), tipos_titularidad=tipos)
        if dlg.exec_() != dlg.Accepted:
            return None
        return dlg.values()

    def _active_tipos_titularidad(self):
        out = []
        for row in self.master_data.get("tipos_titularidad", []):
            if bool(row.get("activo", True)):
                out.append(row)
        out.sort(key=lambda r: str(r.get("codigo") or ""))
        return out

    def _zone_id_by_code(self):
        m = {}
        for row in self.master_data.get("zonas", []):
            code = str(row.get("codigo") or "").strip()
            if code:
                m[code] = str(row.get("id"))
        return m

    def _unit_type_id_by_code(self):
        m = {}
        for row in self.master_data.get("tipos_unidad", []):
            code = str(row.get("codigo") or "").strip()
            if code:
                m[code] = int(row.get("id"))
        return m

    def _build_preview_layer(self, line_layer, metadata):
        project = QgsProject.instance()
        old = project.mapLayersByName("geocodificacion_preview")
        for lyr in old:
            project.removeMapLayer(lyr.id())

        preview = QgsVectorLayer("Point?crs=EPSG:4326", "geocodificacion_preview", "memory")
        if not preview.isValid():
            return None

        pr = preview.dataProvider()
        pr.addAttributes(
            [
                QgsField("ZONE", QVariant.String, len=80),
                QgsField("UNIT_TYPE", QVariant.String, len=80),
                QgsField("TIPO_GEOCO", QVariant.String, len=10),
                QgsField("ROW_NUM", QVariant.Int),
                QgsField("COL_NUM", QVariant.Int),
                QgsField("SRC_FID", QVariant.Int),
                QgsField("ID_ZONA", QVariant.String, len=40),
                QgsField("ID_TIPO_UNI", QVariant.Int),
                QgsField("RESERVADA", QVariant.Int),
                QgsField("ID_TIPO_TIT", QVariant.Int),
                QgsField("OBSERV", QVariant.String, len=255),
            ]
        )
        preview.updateFields()
        qgs_fields = preview.fields()

        zone_code_to_id = self._zone_id_by_code()
        unit_code_to_id = self._unit_type_id_by_code()
        warnings = []
        generated = []
        for feature in line_layer.selectedFeatures():
            feature_points = generate_points_for_feature(feature, qgs_fields)
            for f in feature_points:
                zone_code = str(f["ZONE"] or "").strip()
                unit_code = str(f["UNIT_TYPE"] or "").strip()
                zone_id = zone_code_to_id.get(zone_code)
                unit_id = unit_code_to_id.get(unit_code)
                if not zone_id:
                    warnings.append(f"Zona no mapeada en maestras: '{zone_code}'")
                if unit_id is None:
                    warnings.append(f"Tipo unidad no mapeado en maestras: '{unit_code}'")
                f["ID_ZONA"] = zone_id or ""
                f["ID_TIPO_UNI"] = unit_id if unit_id is not None else None
                f["RESERVADA"] = 1 if metadata["reservada"] else 0
                f["ID_TIPO_TIT"] = metadata["id_tipo_titularidad"]
                f["OBSERV"] = metadata["observaciones"] or ""
                generated.append(f)

        if generated:
            pr.addFeatures(generated)
            preview.updateExtents()
        project.addMapLayer(preview)
        # Deduplicar advertencias manteniendo orden.
        seen = set()
        unique_warnings = []
        for w in warnings:
            if w in seen:
                continue
            seen.add(w)
            unique_warnings.append(w)
        return preview, unique_warnings

    def _payload_unidad_from_preview(self, f):
        id_zona = str(f["ID_ZONA"] or "").strip()
        id_tipo_uni = f["ID_TIPO_UNI"]
        col_num = f["COL_NUM"]  # altura (Y)
        row_num = f["ROW_NUM"]  # numero (X)
        if not id_zona or id_tipo_uni is None or col_num is None or row_num is None:
            return None

        geom = f.geometry()
        if geom is None or geom.isEmpty():
            return None
        p = geom.asPoint()
        zone = str(f["ZONE"] or "").strip()
        numero = str(int(row_num))
        altura = int(col_num)
        codigo = f"{zone}-{numero}-{altura}" if zone else f"{numero}-{altura}"

        payload = {
            "id_zona": id_zona,
            "id_tipo_unidad": int(id_tipo_uni),
            "numero": numero,
            "altura": altura,
            "codigo": codigo,
            "reservada": bool(int(f["RESERVADA"] or 0)),
            "lng": float(p.x()),
            "lat": float(p.y()),
            "observaciones": (str(f["OBSERV"] or "").strip() or None),
        }
        id_tipo_tit = f["ID_TIPO_TIT"]
        payload["id_tipo_titularidad"] = int(id_tipo_tit) if id_tipo_tit is not None else None
        return payload

    def _info(self, message):
        QMessageBox.information(self.iface.mainWindow(), self.menu_name, message)

    def _error(self, message):
        QMessageBox.critical(self.iface.mainWindow(), self.menu_name, message)

