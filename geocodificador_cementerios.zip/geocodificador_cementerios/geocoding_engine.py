from qgis.core import QgsFeature, QgsGeometry, QgsPointXY


def _line_parts(geom: QgsGeometry):
    if geom.isMultipart():
        return [part for part in geom.asMultiPolyline() if part]
    part = geom.asPolyline()
    return [part] if part else []


def _distances_for_columns(total_length: float, n_columns: int):
    if n_columns <= 1:
        return [0.0]
    step = total_length / float(n_columns - 1)
    return [step * i for i in range(n_columns)]


def _columns_rows_from_feature(feature):
    x_from = int(feature["X_FROM"])
    x_to = int(feature["X_TO"])
    y_from = int(feature["Y_FROM"])
    y_to = int(feature["Y_TO"])
    n_rows = y_to - y_from + 1
    n_cols_xy = x_to - x_from + 1
    total_cells = n_cols_xy
    n_cols = (total_cells // n_rows) if n_rows > 0 else 0
    return x_from, x_to, y_from, y_to, n_rows, n_cols_xy, n_cols


def _register(attrs, point_xy, field_names):
    f = QgsFeature()
    f.setFields(field_names)
    f.setGeometry(QgsGeometry.fromPointXY(point_xy))
    f["ZONE"] = attrs["ZONE"]
    f["UNIT_TYPE"] = attrs["UNIT_TYPE"]
    f["TIPO_GEOCO"] = attrs["TIPO_GEOCO"]
    f["ROW_NUM"] = int(attrs["ROW_NUM"])
    f["COL_NUM"] = int(attrs["COL_NUM"])
    f["SRC_FID"] = int(attrs["SRC_FID"])
    return f


def _attrs(zone, unit_type, tipo, numero_x, altura_y, src_fid):
    # Convencion solicitada:
    # - ROW_NUM = numero (X)
    # - COL_NUM = altura (Y)
    return {
        "ZONE": zone,
        "UNIT_TYPE": unit_type,
        "TIPO_GEOCO": tipo,
        "ROW_NUM": int(numero_x),
        "COL_NUM": int(altura_y),
        "SRC_FID": int(src_fid),
    }


def generate_points_for_feature(feature, field_names):
    tipo = str(feature["TIPO_GEOCO"] or "").strip().upper()
    zone = str(feature["ZONE"] if "ZONE" in feature.fields().names() else feature["ZONA"])
    unit_type = str(
        feature["UNIT_TYPE"] if "UNIT_TYPE" in feature.fields().names() else feature["UINIT_TYPE"]
    )
    geom = feature.geometry()
    parts = _line_parts(geom)
    if not parts:
        return []

    x_from, x_to, y_from, y_to, n_rows, n_cols_xy, n_cols = _columns_rows_from_feature(feature)
    out = []

    def part_point_list(part, n_columns):
        g = QgsGeometry.fromPolylineXY(part)
        dists = _distances_for_columns(g.length(), n_columns)
        return [g.interpolate(d).asPoint() for d in dists]

    if tipo == "XY":
        n_columns = n_cols_xy
        row_vals = list(range(y_from, y_to + 1))
        col_vals = list(range(x_from, x_to + 1))
        for row_idx, row_num in enumerate(row_vals):
            part = parts[row_idx] if row_idx < len(parts) else parts[0]
            pts = part_point_list(part, n_columns)
            for col_idx, p in enumerate(pts):
                out.append(
                    _register(
                        _attrs(
                            zone,
                            unit_type,
                            tipo,
                            col_vals[col_idx] if col_idx < len(col_vals) else col_vals[-1],
                            row_num,
                            feature.id(),
                        ),
                        QgsPointXY(p),
                        field_names,
                    )
                )
        return out

    # Modos no-XY requieren n_cols derivado de total/n_rows.
    if n_cols <= 0:
        return []

    row_vals = list(range(y_from, y_to + 1))
    base_part = parts[0]
    pts = part_point_list(base_part, n_cols)

    if tipo == "X_UNI":
        for row_idx, row_num in enumerate(row_vals):
            # Numero (X) debe arrancar en X_FROM.
            start = x_from + (row_idx * n_cols)
            cols = list(range(start, start + n_cols))
            for i, p in enumerate(pts):
                out.append(
                    _register(
                        _attrs(zone, unit_type, tipo, cols[i], row_num, feature.id()),
                        QgsPointXY(p),
                        field_names,
                    )
                )
        return out

    if tipo == "X_BID":
        for row_idx, row_num in enumerate(row_vals):
            # Numero (X) debe arrancar en X_FROM.
            start = x_from + (row_idx * n_cols)
            cols = list(range(start, start + n_cols))
            if row_num % 2 == 0:
                cols.reverse()
            for i, p in enumerate(pts):
                out.append(
                    _register(
                        _attrs(zone, unit_type, tipo, cols[i], row_num, feature.id()),
                        QgsPointXY(p),
                        field_names,
                    )
                )
        return out

    if tipo == "Y_UNI":
        for row_idx, row_num in enumerate(row_vals):
            for i, p in enumerate(pts):
                out.append(
                    _register(
                        # Numero (X) debe arrancar en X_FROM y usar indice de fila relativo.
                        _attrs(zone, unit_type, tipo, x_from + (i * n_rows) + row_idx, row_num, feature.id()),
                        QgsPointXY(p),
                        field_names,
                    )
                )
        return out

    if tipo == "Y_BID":
        for i, p in enumerate(pts):
            # Numero (X) debe arrancar en X_FROM.
            start = x_from + (n_rows * i)
            nums = list(range(start, start + n_rows))
            if i % 2 != 0:
                nums.reverse()
            for row_num in row_vals:
                idx = row_num - y_from
                if idx < 0 or idx >= len(nums):
                    continue
                out.append(
                    _register(
                        _attrs(zone, unit_type, tipo, nums[idx], row_num, feature.id()),
                        QgsPointXY(p),
                        field_names,
                    )
                )
        return out

    return []

