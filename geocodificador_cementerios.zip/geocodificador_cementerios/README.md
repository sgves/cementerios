# Geocodificador de cementerios (scaffold)

Estado actual: base funcional para cargar como plugin en QGIS y probar:

- menu y boton de plugin;
- login a Supabase con email/contrasena;
- recuperacion de maestras (`zonas`, `tipos_titularidad`, `tipos_unidad`);
- sincronizacion de maestras locales en CSV;
- maestras locales listas para vincular manualmente en la configuracion del proyecto QGIS;
- almacenamiento local de URL/key/email en QSettings.
- dialogo de configuracion del plugin (`line_layer_name`, URL, anon key, remember email).

## Instalacion rapida en QGIS (modo desarrollo)

1. Copiar la carpeta `geocodificador_cementerios` en la carpeta de plugins de QGIS.
2. Reiniciar QGIS.
3. Activar plugin en `Complementos > Administrar e instalar complementos`.
4. Abrir `Geocodificador de cementerios > Conectar y cargar maestras`.
5. (Opcional) Abrir `Geocodificador de cementerios > Configuracion`.
6. Ejecutar `Geocodificador de cementerios > Ejecutar geocodificacion (preview)`.
7. Ejecutar `Geocodificador de cementerios > Sincronizar preview a Supabase`.
8. (Opcional) Ejecutar `Geocodificador de cementerios > Sincronizar unidades desde Supabase (solo lectura)`.
9. (Opcional) Ejecutar `Geocodificador de cementerios > Borrar unidades seleccionadas (QGIS + Supabase)`.

Al conectar:

- se crea/actualiza en ruta relativa al proyecto actual (`mapa_geocodificacion.qgz`):
  - `datos/maestra_zonas_local.csv`
  - `datos/maestra_tipos_titularidad_local.csv`
  - `datos/maestra_tipos_unidad_local.csv`
  - `datos/maestra_tipos_geocodificacion_local.csv`
- se sincronizan:
  - `maestra_zonas_local`
  - `maestra_tipos_titularidad_local`
  - `maestra_tipos_unidad_local`
  - `maestra_tipos_geocodificacion_local`
- no se vinculan automaticamente a campos de la capa de lineas;
- debes configurar manualmente las relaciones en el proyecto QGIS.

Compatibilidad: tambien se reconoce `ZONA` y `UINIT_TYPE` si existen en capas antiguas.

## Configuracion del plugin

Menu: `Geocodificador de cementerios > Configuracion`

Campos:

- `Capa lineas referencia` (ej. `lineas_geocodificacion`)
- `Supabase URL`
- `Supabase anon key`
- `Recordar email`

Uso de `line_layer_name`:

- al conectar/sincronizar, el plugin intenta localizar esa capa;
- valida que tenga el esquema esperado para lineas de referencia:
  - `ZONE`, `X_FROM`, `X_TO`, `Y_FROM`, `Y_TO`, `TIPO_GEOCO`, `UNIT_TYPE`;
- compatibilidad legacy: `ZONA` y `UINIT_TYPE`.

## Preview de geocodificacion

Menu: `Geocodificador de cementerios > Ejecutar geocodificacion (preview)`

Comportamiento actual:

- usa `line_layer_name` para localizar la capa de lineas;
- bloquea si la capa no existe o no cumple esquema;
- bloquea si no hay entidades seleccionadas;
- solicita metadatos de lote (reservada, tipo titularidad opcional, observaciones);
- genera capa temporal `geocodificacion_preview` (EPSG:4326) con campos:
  - `ZONE`, `UNIT_TYPE`, `TIPO_GEOCO`, `ROW_NUM`, `COL_NUM`, `SRC_FID`
  - `ID_ZONA`, `ID_TIPO_UNI`, `RESERVADA`, `ID_TIPO_TIT`, `OBSERV`.
  - Convencion: `ROW_NUM = numero (X)` y `COL_NUM = altura (Y)`.

## Sincronizacion a Supabase

Menu: `Geocodificador de cementerios > Sincronizar preview a Supabase`

- requiere sesion iniciada y capa `geocodificacion_preview`;
- usa RPC servidor `fn_unidades_upsert_geocodificacion(p_items jsonb)`;
- estrategia en servidor:
  - busca existencia por `id_zona + numero + altura`;
  - `UPDATE` si existe;
  - `INSERT` si no existe;
- geometria se persiste en servidor con `ST_SetSRID(ST_MakePoint(lng,lat), 4326)`;
- muestra resumen final con insertadas/actualizadas/omitidas/error.

## Capa unidades desde Supabase (solo lectura)

Menu: `Geocodificador de cementerios > Sincronizar unidades desde Supabase (solo lectura)`

- descarga registros desde `vw_unidades_mapa` en paginas;
- crea/reemplaza capa temporal `supabase_unidades_ro` (EPSG:4326);
- pensada para visualizacion y analisis con herramientas QGIS.

## Borrado de unidades seleccionadas

Menu: `Geocodificador de cementerios > Borrar unidades seleccionadas (QGIS + Supabase)`

- toma las entidades seleccionadas en `supabase_unidades_ro`;
- borra por `id_unidad` en Supabase (lotes);
- elimina esas entidades de la capa temporal en QGIS;
- solicita confirmacion antes de ejecutar.

## Siguientes pasos previstos

- validacion y mapeo de capa lineal de referencia;
- dialogo de metadatos previo (reservada, tipo titularidad opcional, observaciones);
- motor de geocodificacion por `TIPO_GEOCO`;
- sync `INSERT/UPDATE` contra Supabase (opcion B).

